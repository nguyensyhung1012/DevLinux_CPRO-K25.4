/**
 * @file buttons.c
 * @brief Cài đặt xử lý nút nhấn: chuyển đổi chế độ, tưới thủ công.
 */

#include <stdio.h>
#include <stdlib.h>   // rand()
#include "buttons.h"
#include "config.h"
#include "actuators.h"

void handle_buttons(void) {
    int random_event = rand() % 50; // Xác suất thấp để sinh sự kiện

    if (random_event == 1) {
        // Chuyển đổi chế độ AUTO <-> MANUAL
        system_config.mode = (system_config.mode == MODE_AUTO) ? MODE_MANUAL : MODE_AUTO;
        printf("[BUTTON] Mode switched to %s\n",
               system_config.mode == MODE_AUTO ? "AUTO" : "MANUAL");

        if (system_config.mode == MODE_MANUAL) {
            turn_pump_off(); // đảm bảo bơm tắt
        }
    } else if (random_event == 2 && system_config.mode == MODE_MANUAL) {
        // Nút tưới thủ công
        printf("[BUTTON] Manual watering for 3 cycles\n");
        turn_pump_on();
        for (int i = 0; i < 3; i++) {
            printf("[MANUAL] Pump running cycle %d\n", i + 1);
        }
        turn_pump_off();
    }
}
